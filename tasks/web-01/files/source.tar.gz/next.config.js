/** @type {import('next').NextConfig} */
const nextConfig = {
  async rewrites() {
    return [
      {
        source: '/bridge/:path*',
        destination:
          'http://127.0.0.1:4000/bridge/:path*',
      },
    ]
  },
}

module.exports = nextConfig
