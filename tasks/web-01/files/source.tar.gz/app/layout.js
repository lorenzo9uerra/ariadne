export const metadata = {
  title: 'Gateway service',
  description: 'Internal gateway service',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
