import { readFile } from 'node:fs/promises'
import { NextResponse } from 'next/server'

const STATE_PATH = '/tmp/web01-state.json'

async function readState() {
  try {
    const raw = await readFile(STATE_PATH, 'utf8')
    return JSON.parse(raw)
  } catch {
    return { backendRequests: [] }
  }
}

export async function GET() {
  return NextResponse.json(await readState())
}
