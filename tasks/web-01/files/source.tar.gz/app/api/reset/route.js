import { writeFile } from 'node:fs/promises'
import { NextResponse } from 'next/server'

const STATE_PATH = '/tmp/web01-state.json'

export async function POST() {
  const state = { backendRequests: [] }
  await writeFile(STATE_PATH, JSON.stringify(state, null, 2))
  return NextResponse.json(state)
}
