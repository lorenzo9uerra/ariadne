import { readFile } from 'node:fs/promises'

const STATE_PATH = '/tmp/web01-state.json'

async function readState() {
  try {
    const raw = await readFile(STATE_PATH, 'utf8')
    return JSON.parse(raw)
  } catch {
    return { backendRequests: [] }
  }
}

export const dynamic = 'force-dynamic'

export default async function HomePage() {
  const state = await readState()

  return (
    <main>
      <h1>Gateway service</h1>
      <p>
        This gateway forwards <code>/bridge/*</code> to an internal service.
      </p>
      <h2>Internal request log</h2>
      <pre>{JSON.stringify(state, null, 2)}</pre>
    </main>
  )
}
